#include<iostream>
#include<fstream>
#include<conio.h>
#include<stdlib.h>
#include<string.h>
#include "report.h"
using namespace std;

int main()
{
    report r;
    r.main_menu();
    return 0;
}
